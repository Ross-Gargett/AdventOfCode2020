﻿using System;
using System.Collections.Generic;
using AdventOfCode.Classes;

namespace $safeprojectname$.Services
{
    class ProblemSolverDayX : IProblemSolver<object>
    {
        public IEnumerable<object> InputLines { get; set; }

        public void ReadInputFile()
        {
            throw new NotImplementedException();
        }

        public void SolvePartOne()
        {
            throw new NotImplementedException();
        }

        public void SolvePartTwo()
        {
            throw new NotImplementedException();
        }
    }
}

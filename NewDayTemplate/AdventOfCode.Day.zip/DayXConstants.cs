﻿namespace $safeprojectname$
{
    class DayXConstants
    {
        #region Day X Constants
        
        public const string DayXPartOneAnswer = "Part 1:\n";
        public const string DayXPartTwoAnswer = "Part 2:\n";

        #endregion
    }
}

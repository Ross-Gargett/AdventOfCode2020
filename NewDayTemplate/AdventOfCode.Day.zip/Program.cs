﻿using System;
using AdventOfCode.Classes;
using AdventOfCode.Classes.Services;
using $safeprojectname$.Services;

namespace $safeprojectname$
{
    class Program : AdventOfCodeProgram
    {
        private static ProblemSolverDayX _problemSolver;
        public static int DayNum { get; } = -1;

        static void Main(string[] args)
        {
            _problemSolver = new ProblemSolverDayX();

            OutputWelcomeMessage(DayNum);

            OutputPartOne(_problemSolver);
            OutputPartTwo(_problemSolver);

            OutputGoodbyeMessage();
        }
    }
}
